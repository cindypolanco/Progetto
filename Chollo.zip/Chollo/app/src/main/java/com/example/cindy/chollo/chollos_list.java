package com.example.cindy.chollo;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.GridView;

import java.util.ArrayList;

public class chollos_list extends AppCompatActivity {

    GridView gridView;
    ArrayList<chollos>list;
    CholloListAdapter adapter = null;


    protected  void onCreate(Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.list_chollos);

        gridView= (GridView)findViewById(R.id.gridview);
        list= new ArrayList<>();
        adapter= new CholloListAdapter(this,R.layout.chollo,list);
        gridView.setAdapter(adapter);

        //get all data from sqlite
        BasedeDatos basedeDatos= new BasedeDatos(this,"ADMI",null,1);
        SQLiteDatabase db=basedeDatos.getReadableDatabase();
        Cursor cursor= db.rawQuery("select * from chollos",null);
        list.clear();
        while(cursor.moveToFirst()){

            byte[]imagen= cursor.getBlob(4);

            String name= cursor.getString(1);

            String description= cursor.getString(2);

            String price= cursor.getString(3);

            String link= cursor.getString(0);


            list.add(new chollos(name,link,imagen,price,description));
            db.close();
        }
        adapter.notifyDataSetChanged();

    }

}
