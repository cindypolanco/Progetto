package com.example.cindy.chollo;

public class chollos {
    private String name;
    private String link;
    private String price;
    private String description;
    private byte[] imagen;

    public chollos(String name,String link,byte[]imagen,String price,String description){

        this.name=name;
        this.link=link;
        this.description=description;
        this.price=price;
        this.imagen=imagen;
    }
    public String getName(){
        return name;
    }
    public  String getLink(){
        return link;
    }
    public  String getPrice(){
        return price;
    }
    public String getDescription(){
        return description;
    }

    public byte[] getImage() {
        return imagen;
    }
    public void setName(String name){
        this.name=name;
    }
    public void setLink(String link){
        this.link=link;
    }

    public void setImage(byte[] imagen) {
        this.imagen = imagen;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
