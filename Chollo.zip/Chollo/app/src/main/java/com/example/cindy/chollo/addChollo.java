package com.example.cindy.chollo;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;

import android.database.sqlite.SQLiteDatabase;

import android.database.sqlite.SQLiteStatement;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;

import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

import java.io.FileNotFoundException;

import java.io.InputStream;



public class addChollo extends AppCompatActivity {

    private EditText et1, et2, et3, et6;
    private Button  pit;
    private ImageView img;
    private static final int PICK_IMG = 999;
    public BasedeDatos basedeDatos;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_chollo);

        et1 = (EditText) findViewById(R.id.txt_namechollo);
        et2 = (EditText) findViewById(R.id.txt_descri);
        et3 = (EditText) findViewById(R.id.txt_precio);
        et6 = (EditText) findViewById(R.id.link);
        img = (ImageView) findViewById(R.id.txt_imagen);
        pit = (Button) findViewById(R.id.buttonimagen);



        pit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityCompat.requestPermissions(
                        addChollo.this, new String[]
                                {Manifest.permission.READ_EXTERNAL_STORAGE}, PICK_IMG);
            }
        });


    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.overflow,menu);
        return true;

    }
    public boolean onOptionsItemSelected(MenuItem item){
        int id= item.getItemId();

        if(id==R.id.txt_home){
            Intent intent= new Intent(this,chollos_list.class);
            startActivity(intent);
        }else if(id==R.id.txt_add){
            Intent intent= new Intent(this,addChollo.class);
            startActivity(intent);
        }else if(id==R.id.app_bar_search){

        }
        return super.onOptionsItemSelected(item);
    }

    public void add(View v) {
        BasedeDatos admi = new BasedeDatos(this, "ADMI", null, 1);
        SQLiteDatabase db= admi.getWritableDatabase();
        String link=et6.getText().toString().trim();
        String name=et1.getText().toString().trim();
        String descrip=et2.getText().toString().trim();
        String price=et3.getText().toString().trim();
         if(link.isEmpty()&&name.isEmpty()&&price.isEmpty()){
             Toast.makeText(this,"Fail empty",Toast.LENGTH_SHORT).show();

        }else {
            /* SQLiteStatement statement = db.compileStatement("insert into chollos values(?,?,?,?,?)");

             statement.clearBindings();
             statement.bindString(1, link);
             statement.bindString(2, name);
             statement.bindString(3, descrip);
             statement.bindString(4, price);
             statement.bindBlob(5, imageViewToByte(img));
             statement.executeInsert();

             et6.setText(" ");
             et1.setText(" ");
             et2.setText(" ");
             et3.setText(" ");
             img.setImageResource(R.mipmap.ic_launcher);

             Toast.makeText(this, "Sucessfully", Toast.LENGTH_SHORT).show();
         }*/
             ContentValues registro= new ContentValues();
             registro.put("link",link);
             registro.put("name",name);
             registro.put("description",descrip);
             registro.put("price",price);
             registro.put("imagen",imageViewToByte(img));
             db.insert("chollos",null,registro);
             db.close();


             et6.setText(" ");
             et1.setText(" ");
             et2.setText(" ");
             et3.setText(" ");
             img.setImageResource(R.mipmap.ic_launcher);

             Toast.makeText(this,"Sucessfully",Toast.LENGTH_SHORT).show();

        }

        }






    public static byte[] imageViewToByte(ImageView image) {

        Bitmap bitmap = ((BitmapDrawable) image.getDrawable()).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        return byteArray;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if (requestCode == PICK_IMG) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent, PICK_IMG);
            } else {
                Toast.makeText(this, "You don't have permission to access file location!", Toast.LENGTH_SHORT).show();
            }
            return;
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == PICK_IMG && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();

            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);

                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                img.setImageBitmap(bitmap);

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }

        super.onActivityResult(requestCode, resultCode, data);
    }


}
