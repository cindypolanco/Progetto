package com.example.cindy.chollo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class CholloListAdapter extends BaseAdapter {
    private Context context;
    private int layout;
    private ArrayList<chollos>cholloslist;

    public CholloListAdapter(Context context,int layout,ArrayList<chollos>cholloslist){
        this.context=context;
        this.layout=layout;
        this.cholloslist=cholloslist;
    }

    @Override
    public int getCount() {
        return cholloslist.size();
    }

    @Override
    public Object getItem(int position) {
        return cholloslist.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class  ViewHolder{
        ImageView imageView;
        TextView txtName, txtPrice,txtLink,txtDescription;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        View row = view;
        ViewHolder holder= new ViewHolder();

        if(row==null){
            LayoutInflater inflater= (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row= inflater.inflate(layout,null);
            holder.txtName=(TextView)row.findViewById(R.id.txtName);
            holder.txtPrice=(TextView)row.findViewById(R.id.txtPrice);
            holder.txtLink=(TextView)row.findViewById(R.id.txtLink);
            holder.txtDescription=(TextView)row.findViewById(R.id.txtDescription);
            holder.imageView= (ImageView)row.findViewById(R.id.txtImagen);
            row.setTag(holder);

        }else{
            holder=(ViewHolder)row.getTag();
        }

        chollos chollos=cholloslist.get(position);

        holder.txtName.setText(chollos.getName());
        holder.txtLink.setText(chollos.getLink());
        holder.txtPrice.setText(chollos.getPrice());
        holder.txtDescription.setText(chollos.getDescription());

        byte[]cholloImg= chollos.getImage();
        Bitmap bitmap= BitmapFactory.decodeByteArray(cholloImg,0,cholloImg.length);
        holder.imageView.setImageBitmap(bitmap);

        return row;

    }



}
