package com.example.cindy.prueba1;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.CursorWindow;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;


public class SQLiteHelper extends SQLiteOpenHelper {

    public SQLiteHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    public void queryData(String sql){
        SQLiteDatabase database = getWritableDatabase();
        database.execSQL(sql);
    }

    public void insertData( String price, byte[] image, String link){
        SQLiteDatabase database = getWritableDatabase();
        String sql = "INSERT INTO CHOLLO VALUES (null, ?, ?, ?)";

        SQLiteStatement statement= database.compileStatement(sql);
        statement.bindString(1, link);
        statement.bindString(2, price);
        statement.bindBlob(3, image);


        statement.executeInsert();

    }

    public void updateData(String price, byte[] image, int id,String link) {
        SQLiteDatabase database = getWritableDatabase();

        String sql = "UPDATE CHOLLO SET name = ?, price = ?, image = ? ,link= ? WHERE id = ?";
        SQLiteStatement statement = database.compileStatement(sql);

        statement.bindString(1, price);
        statement.bindBlob(2, image);
        statement.bindString(3,link);
        statement.bindDouble(5, (double)id);

        statement.execute();
        database.close();
    }

    public  void deleteData(int id) {
        SQLiteDatabase database = getWritableDatabase();

        String sql = "DELETE FROM CHOLLO WHERE id = ?";
        SQLiteStatement statement = database.compileStatement(sql);
        statement.clearBindings();
        statement.bindDouble(1, (double)id);

        statement.execute();
        database.close();
    }

    public Cursor getData(String sql){
        SQLiteDatabase database = getReadableDatabase();
        return database.rawQuery(sql, null);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
