package com.example.cindy.prueba1;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Quoc Nguyen on 13-Dec-16.
 */

public class CholloListAdapter extends BaseAdapter {

    private Context context;
    private  int layout;
    private ArrayList<Chollo> cholloList;

    public CholloListAdapter(Context context, int layout, ArrayList<Chollo> foodsList) {
        this.context = context;
        this.layout = layout;
        this.cholloList = foodsList;
    }

    @Override
    public int getCount() {
        return cholloList.size();
    }

    @Override
    public Object getItem(int position) {
        return cholloList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class ViewHolder{
        ImageView imageView;
        TextView txtName, txtPrice, txtLink;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        View row = view;
        ViewHolder holder = new ViewHolder();

        if(row == null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(layout, null);

          //  holder.txtName = (TextView) row.findViewById(R.id.txtName);
            holder.txtPrice = (TextView) row.findViewById(R.id.txtPrice);
            holder.imageView = (ImageView) row.findViewById(R.id.imgChollo);
            holder.txtLink=(TextView) row.findViewById(R.id.txtLink);
            row.setTag(holder);
        }
        else {
            holder = (ViewHolder) row.getTag();
        }

        Chollo chollo = cholloList.get(position);

        //holder.txtName.setText(chollo.getName());
        holder.txtPrice.setText(chollo.getPrice());
        holder.txtLink.setText(chollo.getLink());

        byte[] foodImage = chollo.getImage();
        Bitmap bitmap = BitmapFactory.decodeByteArray(foodImage, 0, foodImage.length);
        holder.imageView.setImageBitmap(bitmap);

        return row;
    }
}
