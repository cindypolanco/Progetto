package com.example.cindy.prueba1;

public class Chollo {
    private int id;
    private String name;
    private String price;
    private byte[] image;
    private String link;

    public Chollo( String price, byte[] image,String link) {
        this.name = name;
        this.price = price;
       this.image = image;
        this.id = id;
        this.link=link;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }
    public String getLink(){
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
